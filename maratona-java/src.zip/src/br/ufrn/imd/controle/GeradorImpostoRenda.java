package br.ufrn.imd.controle;

public class GeradorImpostoRenda {

}
