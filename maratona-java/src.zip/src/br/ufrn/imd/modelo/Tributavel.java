package br.ufrn.imd.modelo;

public interface Tributavel {
    double calculaTributos();
}